# SleepBubble 0.1

App Android nativa para registrar horas de acostarse y usos posteriores, con burbuja movible.
Android 8 o posterior. Datos locales, sin Internet, root ni Shizuku.

## Uso

1. Instala la APK, abre SleepBubble y permite la ventana flotante.
2. Activa la burbuja. Toca el símbolo para desplegarla; arrastra el símbolo para moverla.
3. Toca **Me voy a dormir**. Guarda fecha y hora de inmediato.
4. El primer desbloqueo, o encendido sin bloqueo, registra un despertar provisional.
5. Si la pantalla sigue interactiva y desbloqueada cinco minutos, cierra la sesión usando la hora inicial. Si se apaga antes, conserva el evento y sigue registrando usos. Esta regla es una aproximación y puede equivocarse tanto de madrugada como al despertar.
6. **Cancelar / seguir durmiendo** elimina la sesión abierta (cancelación); si la última está cerrada, la reabre conservando horas y eventos.
7. El historial permite corregir fecha y hora y compartir texto mediante el menú Android.

No detecta el momento real en que te duermes ni fases de sueño. El intervalo entre marcas no equivale a sueño efectivo. Tampoco envía datos a ChatGPT por sí solo.

La notificación permanente mantiene el servicio que recibe eventos; no se utiliza wakelock ni cronómetro mientras la pantalla está apagada. Si Android detiene el servicio, conserva lo ya guardado pero puede perder eventos. En Tecno puede ser necesario habilitar inicio automático y permitir ejecución en segundo plano. Reinicio intenta restaurar la burbuja; tras forzar detención hay que abrir la app otra vez.

## GitHub

Sube estos archivos a la raíz de un repositorio nuevo (incluyendo `.github`). El flujo **Build SleepBubble APK** compila con cada push y deja el artefacto **SleepBubble-APK** en Actions.

Alternativa local: instala SDK Android API 35 y build-tools 35.0.0, exporta ANDROID_SDK_ROOT y ejecuta `bash build.sh` con Java 17.

La APK entregada utiliza firma de desarrollo. Conserva la clave local para futuras actualizaciones. El workflow usa una clave temporal: para distribuir actualizaciones que se instalen sobre la misma app, configura una clave estable mediante secretos antes de publicar versiones siguientes. Nunca subas la clave privada al repositorio.

## Validación

Compilación Java y dex, empaquetado y verificación de firma/manifest. Pruebas del diario con almacenamiento simulado: persistencia, eliminación de eventos duplicados, intervalo nocturno, reapertura tras un falso despertar, corrección, cancelación que conserva noches anteriores y exportación. Aún requiere probar burbuja y detección de eventos en un teléfono real; no se ha probado en el Tecno del usuario.
