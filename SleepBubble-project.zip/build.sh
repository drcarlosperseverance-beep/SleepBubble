#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
sdk="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-}}"
if [[ -z "$sdk" ]]; then echo 'Set ANDROID_SDK_ROOT to an Android SDK with API 35 and build-tools 35.0.0' >&2; exit 1; fi
bt="$sdk/build-tools/35.0.0"
platform="$sdk/platforms/android-35/android.jar"
mkdir -p build/classes build/dex
"$bt/aapt2" link -o build/base.apk --manifest app/src/main/AndroidManifest.xml -I "$platform"
find app/src/main/java -name '*.java' > build/sources.txt
javac -encoding UTF-8 -source 8 -target 8 -bootclasspath "$platform:$bt/core-lambda-stubs.jar" -d build/classes @build/sources.txt
find build/classes -name '*.class' > build/classes.txt
"$bt/d8" --min-api 26 --lib "$platform" --output build/dex @build/classes.txt
cp build/base.apk build/unsigned.apk
(cd build/dex && zip -q ../unsigned.apk classes.dex)
"$bt/zipalign" -f -p 4 build/unsigned.apk build/aligned.apk
keystore="${SLEEPBUBBLE_KEYSTORE:-build/sleepbubble-dev.keystore}"
if [[ ! -f "$keystore" ]]; then keytool -genkeypair -keystore "$keystore" -storepass android -keypass android -alias sleepbubble -dname 'CN=SleepBubble development' -keyalg RSA -keysize 2048 -validity 10000 >/dev/null 2>&1; fi
"$bt/apksigner" sign --ks "$keystore" --ks-pass pass:android --ks-key-alias sleepbubble --out build/SleepBubble-v0.1.apk build/aligned.apk
"$bt/apksigner" verify --verbose build/SleepBubble-v0.1.apk
"$bt/aapt2" dump badging build/SleepBubble-v0.1.apk
