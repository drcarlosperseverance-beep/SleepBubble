package com.yamil.sleepbubble;
import android.content.*;
import android.provider.Settings;
public class BootReceiver extends BroadcastReceiver {
    public void onReceive(Context c,Intent i) {if(new Diary(c).enabled()&&Settings.canDrawOverlays(c))try{c.startForegroundService(new Intent(c,BubbleService.class));}catch(RuntimeException e){/* Opening the app restarts the user-controlled service. */}}
}
