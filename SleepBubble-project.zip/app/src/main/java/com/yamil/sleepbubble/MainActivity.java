package com.yamil.sleepbubble;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.widget.*;
import org.json.*;
import java.text.*;
import java.util.*;

public class MainActivity extends Activity {
    Diary diary;LinearLayout content;
    public void onCreate(Bundle s){super.onCreate(s);diary=new Diary(this);}
    public void onResume(){super.onResume();draw();}
    void text(String t,int size){TextView v=new TextView(this);v.setText(t);v.setTextColor(Color.WHITE);v.setTextSize(size);v.setPadding(0,12,0,12);content.addView(v);}
    void button(String t,Runnable r){Button b=new Button(this);b.setText(t);content.addView(b);b.setOnClickListener(v->r.run());}
    void draw(){ScrollView scroll=new ScrollView(this);content=new LinearLayout(this);content.setOrientation(1);content.setPadding(28,32,28,40);content.setBackgroundColor(Color.rgb(15,23,39));scroll.addView(content);setContentView(scroll);text("🌙 SleepBubble",28);text("Un toque antes de dormir. Tu próximo uso queda registrado.",17);
        text("La burbuja se arrastra desde el símbolo. Tócala para desplegar los botones. No mantiene un cronómetro mientras la pantalla está apagada.",14);
        if(!Settings.canDrawOverlays(this))button("1. Permitir ventana flotante",()->startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName()))));
        if(Build.VERSION.SDK_INT>=33&&checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=android.content.pm.PackageManager.PERMISSION_GRANTED)button("Permitir notificación",()->requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},3));
        button("Activar burbuja",()->{if(!Settings.canDrawOverlays(this)){Toast.makeText(this,"Primero permite la ventana flotante",Toast.LENGTH_LONG).show();return;}startForegroundService(new Intent(this,BubbleService.class));});
        button("Ocultar burbuja",()->{diary.enabled(false);stopService(new Intent(this,BubbleService.class));});
        button("Me voy a dormir",()->{if(!diary.enabled()){Toast.makeText(this,"Activa primero la burbuja",Toast.LENGTH_LONG).show();return;}diary.start(System.currentTimeMillis());startForegroundService(new Intent(this,BubbleService.class));draw();});
        text("Despertar automático: registra el primer desbloqueo (o pantalla encendida si no hay bloqueo). Si mantienes el teléfono desbloqueado 5 minutos, cierra la noche usando la hora del primer uso. Si lo apagas antes, conserva ese uso como posible despertar nocturno y sigue registrando. Puedes corregirlo o pulsar «seguir durmiendo». No mide sueño real.",14);
        text("En Tecno: si faltan registros, permite el inicio automático y quita la restricción de batería para SleepBubble. Si Android cierra el servicio, las horas ya guardadas permanecen; no se inventan eventos perdidos.",14);
        button("Compartir historial",()->{Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_TEXT,diary.export());startActivity(Intent.createChooser(i,"Compartir registro"));});
        text("Historial",23);JSONArray a=diary.all();if(a.length()==0)text("Todavía no hay noches guardadas.",16);for(int j=a.length()-1;j>=0;j--){final int index=j;JSONObject s=a.optJSONObject(j);long bed=s.optLong("bed"),wake=s.optLong("wake");text("Me acosté: "+Diary.stamp(bed)+"\nDespertar "+(s.optBoolean("active")?"provisional":"estimado")+": "+Diary.stamp(wake)+"\nIntervalo: "+Diary.duration(bed,wake),17);JSONArray ev=s.optJSONArray("events");StringBuilder events=new StringBuilder("Usos: ");for(int k=0;ev!=null&&k<ev.length();k++)events.append(Diary.stamp(ev.optLong(k))).append("  ");text(events.toString(),13);button("Corregir estas horas",()->edit(index,bed,wake));} }
    void edit(int index,long bed,long wake){LinearLayout form=new LinearLayout(this);form.setOrientation(1);EditText b=new EditText(this),w=new EditText(this);b.setSingleLine(true);w.setSingleLine(true);b.setText(Diary.stamp(bed));w.setText(wake==0?"":Diary.stamp(wake));b.setHint("dd/MM/yyyy HH:mm · acostarse");w.setHint("dd/MM/yyyy HH:mm · despertar");form.addView(b);form.addView(w);AlertDialog dlg=new AlertDialog.Builder(this).setTitle("Fecha y hora (24 horas)").setView(form).setPositiveButton("Guardar",null).setNegativeButton("Cancelar",null).create();dlg.setOnShowListener(v->dlg.getButton(-1).setOnClickListener(view->{try{SimpleDateFormat fmt=new SimpleDateFormat("dd/MM/yyyy HH:mm",Locale.getDefault());fmt.setLenient(false);long bt=parse(fmt,b.getText().toString()),wt=w.getText().toString().trim().isEmpty()?0:parse(fmt,w.getText().toString());if(wt!=0&&wt<bt)throw new IllegalArgumentException();diary.edit(index,bt,wt);dlg.dismiss();draw();}catch(Exception e){Toast.makeText(this,"Revisa el formato y que el despertar sea posterior",Toast.LENGTH_LONG).show();}}));dlg.show();}
    long parse(SimpleDateFormat fmt,String text)throws Exception{ParsePosition p=new ParsePosition(0);Date d=fmt.parse(text.trim(),p);if(d==null||p.getIndex()!=text.trim().length())throw new IllegalArgumentException();return d.getTime();}
}
