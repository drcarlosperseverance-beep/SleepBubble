package com.yamil.sleepbubble;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.*;
import java.text.SimpleDateFormat;
import java.util.*;

final class Diary {
    private final SharedPreferences prefs;
    Diary(Context c) { prefs=c.getSharedPreferences("diary",0); }
    boolean enabled() { return prefs.getBoolean("enabled",false); }
    void enabled(boolean on) { prefs.edit().putBoolean("enabled",on).commit(); }
    JSONArray all() { try { return new JSONArray(prefs.getString("sessions","[]")); } catch(JSONException e) { return new JSONArray(); } }
    private void save(JSONArray a) { prefs.edit().putString("sessions",a.toString()).commit(); }
    JSONObject active() { JSONArray a=all(); if(a.length()==0)return null; JSONObject s=a.optJSONObject(a.length()-1); return s!=null&&s.optBoolean("active")?s:null; }
    void start(long now) { JSONArray a=all(); if(active()!=null)return; JSONObject s=new JSONObject(); try {s.put("bed",now);s.put("active",true);s.put("events",new JSONArray());a.put(s);save(a);}catch(JSONException e){throw new IllegalStateException(e);} }
    void use(long now) { JSONArray a=all(); JSONObject s=active(); if(s==null)return; JSONArray events=s.optJSONArray("events"); if(events==null)events=new JSONArray(); if(events.length()>0 && now-events.optLong(events.length()-1)<30000)return; events.put(now); try{s.put("events",events);s.put("wake",now);a.put(a.length()-1,s);save(a);}catch(JSONException e){throw new IllegalStateException(e);} }
    void finish(long wake) { JSONArray a=all();JSONObject s=active();if(s==null)return; try { if(wake>0)s.put("wake",wake);s.put("active",false);a.put(a.length()-1,s);save(a);}catch(JSONException e){throw new IllegalStateException(e);} }
    void cancel() {JSONArray a=all();if(active()!=null){a.remove(a.length()-1);save(a);} }
    void resumeLast() {JSONArray a=all();if(a.length()==0)return;JSONObject s=a.optJSONObject(a.length()-1);try{s.put("active",true);a.put(a.length()-1,s);save(a);}catch(JSONException e){throw new IllegalStateException(e);} }
    void edit(int index,long bed,long wake) {JSONArray a=all();JSONObject s=a.optJSONObject(index);try{s.put("bed",bed);if(wake==0)s.remove("wake");else s.put("wake",wake);a.put(index,s);save(a);}catch(JSONException e){throw new IllegalStateException(e);} }
    static String stamp(long t) {return t==0?"—":new SimpleDateFormat("dd/MM/yyyy HH:mm",Locale.getDefault()).format(new Date(t));}
    static String duration(long b,long w) {if(w<=0)return "pendiente";long mins=Math.max(0,(w-b)/60000);return (mins/60)+" h "+(mins%60)+" min";}
    String export() {StringBuilder out=new StringBuilder("SleepBubble · diario de descanso\nSon horas registradas, no medición del sueño.\n\n");JSONArray a=all();for(int i=a.length()-1;i>=0;i--){JSONObject s=a.optJSONObject(i);out.append("Me acosté: ").append(stamp(s.optLong("bed"))).append("\nDespertar estimado: ").append(stamp(s.optLong("wake"))).append("\nIntervalo: ").append(duration(s.optLong("bed"),s.optLong("wake"))).append(s.optBoolean("active")?" (seguimiento abierto)":"").append("\nUsos registrados: ");JSONArray ev=s.optJSONArray("events");for(int j=0;ev!=null&&j<ev.length();j++)out.append(stamp(ev.optLong(j))).append(j+1<ev.length()?", ":"");out.append("\n\n");}return out.toString();}
}
