package com.yamil.sleepbubble;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;

public class BubbleService extends Service {
    static final String CHANNEL="sleepbubble";
    Diary diary; WindowManager wm; LinearLayout panel; WindowManager.LayoutParams lp;
    final Handler handler=new Handler(Looper.getMainLooper());
    long candidate=0; boolean recorded=false, expanded=false; TextView title; Button sleep;
    final Runnable finalizeWake=()->{if(diary.active()!=null&&candidate>0&&isUnlocked()){diary.finish(candidate);candidate=0;render();}};
    final BroadcastReceiver receiver=new BroadcastReceiver(){public void onReceive(Context c,Intent i){String a=i.getAction();if(Intent.ACTION_SCREEN_OFF.equals(a)){recorded=false;candidate=0;handler.removeCallbacks(finalizeWake);}else if(Intent.ACTION_SCREEN_ON.equals(a)){recorded=false;if(isUnlocked())recordUse();}else if(Intent.ACTION_USER_PRESENT.equals(a))recordUse();}};
    boolean isUnlocked(){return ((PowerManager)getSystemService(POWER_SERVICE)).isInteractive()&&!((KeyguardManager)getSystemService(KEYGUARD_SERVICE)).isKeyguardLocked();}
    void recordUse(){if(recorded||diary.active()==null)return;recorded=true;candidate=System.currentTimeMillis();diary.use(candidate);handler.removeCallbacks(finalizeWake);handler.postDelayed(finalizeWake,5*60*1000);render();}
    public void onCreate(){super.onCreate();diary=new Diary(this);NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);nm.createNotificationChannel(new NotificationChannel(CHANNEL,"Registro de descanso",NotificationManager.IMPORTANCE_LOW));startForeground(1,notification());IntentFilter f=new IntentFilter();f.addAction(Intent.ACTION_SCREEN_OFF);f.addAction(Intent.ACTION_SCREEN_ON);f.addAction(Intent.ACTION_USER_PRESENT);if(Build.VERSION.SDK_INT>=33)registerReceiver(receiver,f,Context.RECEIVER_NOT_EXPORTED);else registerReceiver(receiver,f);wm=(WindowManager)getSystemService(WINDOW_SERVICE);}
    Notification notification(){PendingIntent open=PendingIntent.getActivity(this,0,new Intent(this,MainActivity.class),PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);PendingIntent stop=PendingIntent.getService(this,1,new Intent(this,BubbleService.class).setAction("STOP"),PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);return new Notification.Builder(this,CHANNEL).setContentTitle("SleepBubble activa").setContentText("Burbuja y registro de desbloqueos · toca para ver el historial").setSmallIcon(android.R.drawable.ic_menu_recent_history).setContentIntent(open).setOngoing(true).addAction(new Notification.Action.Builder(null,"Ocultar burbuja",stop).build()).build();}
    public int onStartCommand(Intent i,int flags,int id){if(i!=null&&"STOP".equals(i.getAction())){diary.enabled(false);stopSelf();return START_NOT_STICKY;}if(!Settings.canDrawOverlays(this)){diary.enabled(false);stopSelf();return START_NOT_STICKY;}diary.enabled(true);if(panel==null)showBubble();else render();return START_STICKY;}
    int dp(int n){return (int)(n*getResources().getDisplayMetrics().density);}
    void showBubble(){panel=new LinearLayout(this);panel.setOrientation(1);panel.setPadding(dp(10),dp(8),dp(10),dp(8));panel.setBackgroundColor(Color.rgb(27,37,55));title=new TextView(this);title.setTextColor(Color.WHITE);title.setTextSize(16);title.setPadding(dp(6),dp(6),dp(6),dp(6));panel.addView(title);sleep=button("",()->{handler.removeCallbacks(finalizeWake);candidate=0;recorded=false;if(diary.active()==null){diary.start(System.currentTimeMillis());Toast.makeText(this,"Hora guardada. Apaga la pantalla cuando quieras.",Toast.LENGTH_LONG).show();}else{diary.finish(System.currentTimeMillis());Toast.makeText(this,"Despertar marcado manualmente",Toast.LENGTH_SHORT).show();}render();});button("Historial",()->{startActivity(new Intent(this,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));});button("Cancelar / seguir durmiendo",()->{if(diary.active()!=null)diary.cancel();else diary.resumeLast();handler.removeCallbacks(finalizeWake);candidate=0;recorded=false;render();});lp=new WindowManager.LayoutParams(dp(245),WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT);lp.gravity=Gravity.TOP|Gravity.LEFT;lp.x=dp(16);lp.y=dp(180);wm.addView(panel,lp);title.setOnTouchListener(new View.OnTouchListener(){float sx,sy;int ox,oy;boolean moved;public boolean onTouch(View v,android.view.MotionEvent e){if(e.getAction()==0){sx=e.getRawX();sy=e.getRawY();ox=lp.x;oy=lp.y;moved=false;return true;}if(e.getAction()==2){float dx=e.getRawX()-sx,dy=e.getRawY()-sy;if(Math.abs(dx)+Math.abs(dy)>dp(8))moved=true;lp.x=Math.max(0,ox+(int)dx);lp.y=Math.max(0,oy+(int)dy);wm.updateViewLayout(panel,lp);return true;}if(e.getAction()==1){if(!moved){expanded=!expanded;render();}return true;}return false;}});render();}
    Button button(String text,Runnable action){Button b=new Button(this);b.setText(text);b.setTextSize(13);panel.addView(b);b.setOnClickListener(v->action.run());return b;}
    void render(){if(panel==null)return;boolean active=diary.active()!=null;title.setText(expanded?(active?"🌙 Desde "+Diary.stamp(diary.active().optLong("bed")):"☀ SleepBubble"):(active?"🌙":"☀"));sleep.setText(active?"Ya desperté (manual)":"Me voy a dormir");((Button)panel.getChildAt(3)).setText(active?"Cancelar registro":"Seguir durmiendo");for(int i=1;i<panel.getChildCount();i++)panel.getChildAt(i).setVisibility(expanded?View.VISIBLE:View.GONE);lp.width=dp(expanded?245:64);wm.updateViewLayout(panel,lp);}
    public void onDestroy(){handler.removeCallbacksAndMessages(null);unregisterReceiver(receiver);if(panel!=null)wm.removeView(panel);super.onDestroy();}
    public IBinder onBind(Intent i){return null;}
}
